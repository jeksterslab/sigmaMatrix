#' @rdname .check_vechsigmacap
#' @noRd
.check_vechcov <- function(x,
                           return_k = FALSE) {
  .check_vechsigmacap(
    x = x,
    return_k = return_k
  )
}
