#' @rdname sigmacap
#' @export
covc <- function(x) {
  sigmacap(x)
}
