#' @rdname .check_sigmacap
#' @noRd
.check_cov <- function(x,
                       return_k = FALSE) {
  .check_sigmacap(
    x = x,
    return_k = return_k
  )
}
