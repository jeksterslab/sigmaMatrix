library(testthat)
library(sigmaMatrix)

test_check("sigmaMatrix")
